<?php
  require("includes.inc");
  if ($conn->connect_error) {
    $conn->close();
    die(DB_CONNECT_ERROR_NOTIF);
  } else {
    $conn->close();
    die(DB_CONNECT_SUCCESS_NOTIF);
  }

  $query = "SELECT id, description, size, price, aisle_id from products WHERE id=? LIMIT 1";

  $stmt = $conn->prepare($query);
  $stmt->bind_result($id, $description, $size, $price, $aisle_id);
  $stmt->bind_param("i", $productId);
  $stmt->execute();
  $stmt->store_result();
?>
